# ADS-Orazgeldi-Nursultan-Assigment2
This project implements data structures as LinkedList,ArrayList,MinHeap,Queue and Stack
MyLinkeList implements doubly linked list, that allows efficiently insertind and deleting the elements
MyArrayList implements dynamic array,where we can access effficently random elements and resize it
MyQueue implementing LinkedList,but it follows the principle First-In-First-Out - FIFO.The elements are added at the end and deleted at front
Mystack are made by using an LinkedList as a basic structure and follows the principle Last-Out-First-In or in other word LIFO.The elements are added and deleted at the same end
MyMinHeap unlike queue and stack implements ArrayList. MinHeap is basically binary min=heap,where you can do actions like heapifying the maintain the heap property and extracting,inserting a minimum element
The comments are wrote in the code using //
